// Risk Score =
// 40% low balance activity
// + 30% excessive focus activity
// + 20% low event attendance
// + 10% inactivity

// Balance score:
// 0 balance events = 100 risk
// 1 balance event  = 70 risk
// 2 balance events = 40 risk
// 3+ balance events = 0 risk

// Focus score:
// 0–3 focus events = 0 risk
// 4–5 focus events = 40 risk
// 6–7 focus events = 70 risk
// 8+ focus events  = 100 risk

// Attendance score:
// 0 attended events = 100 risk
// 1 event           = 70 risk
// 2 events          = 40 risk
// 3+ events         = 0 risk

// Inactivity score:
// 7+ inactive days = 100 risk
// 4–6 days         = 60 risk
// 2–3 days         = 30 risk
// 0–1 day          = 0 risk

// 0–34   = low
// 35–59  = medium
// 60–100 = high

import { supabase } from "../libs/supabase";

const clampScore = (value) =>
  Math.min(100, Math.max(0, Math.round(Number(value) || 0)));

const getMondayDate = (date = new Date()) => {
  const monday = new Date(date);

  monday.setHours(0, 0, 0, 0);

  const daysSinceMonday = (monday.getDay() + 6) % 7;

  monday.setDate(monday.getDate() - daysSinceMonday);

  return monday.toISOString().split("T")[0];
};

const calculateBalanceRisk = (balanceEvents) => {
  if (balanceEvents >= 3) return 0;
  if (balanceEvents === 2) return 40;
  if (balanceEvents === 1) return 70;

  return 100;
};

const calculateFocusRisk = (focusEvents) => {
  if (focusEvents >= 8) return 100;
  if (focusEvents >= 6) return 70;
  if (focusEvents >= 4) return 40;

  return 0;
};

const calculateAttendanceRisk = (attendanceCount) => {
  if (attendanceCount >= 3) return 0;
  if (attendanceCount === 2) return 40;
  if (attendanceCount === 1) return 70;

  return 100;
};

const calculateInactivityRisk = (lastActiveAt) => {
  if (!lastActiveAt) return 100;

  const lastActiveDate = new Date(lastActiveAt);

  if (Number.isNaN(lastActiveDate.getTime())) {
    return 100;
  }

  const millisecondsPerDay = 1000 * 60 * 60 * 24;

  const inactiveDays = Math.floor(
    (Date.now() - lastActiveDate.getTime()) / millisecondsPerDay,
  );

  if (inactiveDays >= 7) return 100;
  if (inactiveDays >= 4) return 60;
  if (inactiveDays >= 2) return 30;

  return 0;
};

const getRiskLevel = (riskScore) => {
  if (riskScore >= 70) return "high";
  if (riskScore >= 40) return "medium";

  return "low";
};

export const calculateStudentRiskScore = ({
  focusEvents = 0,
  balanceEvents = 0,
  attendanceCount = 0,
  lastActiveAt = null,
}) => {
  const balanceRisk = calculateBalanceRisk(balanceEvents);
  const focusRisk = calculateFocusRisk(focusEvents);
  const attendanceRisk = calculateAttendanceRisk(attendanceCount);
  const inactivityRisk = calculateInactivityRisk(lastActiveAt);

  const riskScore = clampScore(
    balanceRisk * 0.4 +
      focusRisk * 0.3 +
      attendanceRisk * 0.2 +
      inactivityRisk * 0.1,
  );

  return {
    riskScore,
    riskLevel: getRiskLevel(riskScore),
    breakdown: {
      balanceRisk,
      focusRisk,
      attendanceRisk,
      inactivityRisk,
    },
  };
};

export const calculateAndSaveBurnoutScores = async () => {
  const weekStart = getMondayDate();

  const { data: students, error: studentsError } = await supabase
    .from("users")
    .select("id, last_active_at")
    .eq("role", "student");

  if (studentsError) {
    throw studentsError;
  }

  const { data: attendanceRows, error: attendanceError } = await supabase
    .from("attendance")
    .select(
      `
      student_id,
      attended_at,
      campus_events!attendance_event_id_fkey (
        category
      )
    `,
    )
    .gte("attended_at", `${weekStart}T00:00:00`);

  if (attendanceError) {
    throw attendanceError;
  }

  const studentActivityMap = new Map();

  (students || []).forEach((student) => {
    studentActivityMap.set(student.id, {
      studentId: student.id,
      lastActiveAt: student.last_active_at,
      focusEvents: 0,
      balanceEvents: 0,
      attendanceCount: 0,
    });
  });

  (attendanceRows || []).forEach((attendance) => {
    const studentActivity = studentActivityMap.get(attendance.student_id);

    if (!studentActivity) {
      return;
    }

    const event = Array.isArray(attendance.campus_events)
      ? attendance.campus_events[0]
      : attendance.campus_events;

    const category = String(event?.category || "")
      .trim()
      .toLowerCase();

    studentActivity.attendanceCount += 1;

    if (category === "focus") {
      studentActivity.focusEvents += 1;
    }

    if (category === "balance") {
      studentActivity.balanceEvents += 1;
    }
  });

  const scoreRows = Array.from(studentActivityMap.values()).map(
    (studentActivity) => {
      const result = calculateStudentRiskScore(studentActivity);

      return {
        student_id: studentActivity.studentId,
        week_start: weekStart,
        risk_score: result.riskScore,
        risk_level: result.riskLevel,
        factors: result.breakdown,
        updated_at: new Date().toISOString(),
      };
    },
  );

  const { data, error } = await supabase
    .from("burnout_risk_scores")
    .upsert(scoreRows, {
      onConflict: "student_id,week_start",
    })
    .select();

  if (error) {
    throw error;
  }

  return data || [];
};