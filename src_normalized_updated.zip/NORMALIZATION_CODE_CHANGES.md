# Frontend updates for the normalized Supabase schema

Updated areas:
- User profiles now join `faculties`, `programmes`, and `user_interests`.
- Student programme completion writes `faculty_id` and `programme_id`.
- Campus events now calculate RSVP totals from `event_rsvps`.
- Personalized match data loads from `event_recommendations` when a student ID is supplied.
- Event topic tags load/write through `event_tags` and `campus_event_tags`.
- Club events now load from `campus_events.club_id`; `club_events` is no longer queried.
- Club member totals now come from `club_members`; `clubs.member_count` is no longer queried.
- Student schedules now use `programme_id` and join `programmes`.
- Attendance writes `attended_at` and the valid `check-in` value.
- Per-event interested/hidden UI preferences remain in localStorage instead of `users.interests`.
- Admin Dashboard event CRUD was updated for normalized event columns.

## Important server-side note
The uploaded archive contained only `src/`. If `/api/create-admin` is in a separate `api/` directory, update it so it resolves the submitted faculty name to `faculties.id` and writes `users.faculty_id` instead of the removed `users.faculty` column.
